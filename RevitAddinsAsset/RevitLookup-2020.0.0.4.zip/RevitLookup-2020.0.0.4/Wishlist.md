Wishlist
========

Jeremy Tammik
-------------

Integrate [GeoSnoop][1]

[1]: http://thebuildingcoder.typepad.com/blog/2013/04/geosnoop-net-boundary-curve-loop-visualisation.html 'GeoSnoop'

Rudolf Honke
------------

- 3D-Control
- Palette
- Modeless, MDI, Docking
