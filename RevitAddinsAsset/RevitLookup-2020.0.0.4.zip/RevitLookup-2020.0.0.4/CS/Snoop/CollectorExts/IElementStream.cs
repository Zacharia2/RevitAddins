using System;

namespace RevitLookup.Snoop.CollectorExts
{
    public interface IElementStream
    {
        void Stream(Type type);
    }
}